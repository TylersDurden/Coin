/* Connect.java */
import java.net.URL;
import java.net.*;
import java.io.*;
import java.util.regex.*;
import java.nio.file.FileSystem;
import java.nio.file.*;

/* This class monitors the price of 4 major Bitcoin exchanges,
 * and keeps track of positive and negative changes for each
 * exchange with respect to time. 
 * 
 * Compilation Connect.java (no Dependencies)
 * 
 * @author scottrobbins
 */
public class Connect {

    private static String     link0;
    int                       sz0;
   
    private static String[]   code    = new String[1000];
    private static double[][] history = new double[4][100];

    static long               start;
    static long               now;
    static long               delt;
    final static long         begin   = System.currentTimeMillis();
    static int                time;

    static String[]           markets = {"Bistamp", "Bitfinex", "OKCoin", "CoinBase"};

    static boolean            stamp;
    static boolean            ok;
    static boolean            bif;
    static boolean            coin;
    //save history of + and - changes for each market
    static double[][]         minus   = new double[4][100];
    static double[][]         plus    = new double[4][100];
    static double[][]         movmt    = new double[4][100];

    public Connect() throws InterruptedException {

        time = 0;
        link0 = "https://www.bitcoinwisdom.com";
       //maybe rotate through several links to cross reference prices,
       //but also be able to query faster 
       
        /*
         * Keep checking every 3 seconds until program 
         * is killed. 
         */
        while (true) {
            quickRun();
            parse();
            calc(0);calc(1);calc(2);calc(3);
            time += 1;
            Thread.sleep(3000);
            //will change to 5 seconds or even 10 when project is complete 
        }


    }

    /* This method writes parameter String info to a text file 
    called "dat.txt*/
    private void log(String info) {
        BufferedWriter writer = null;
        try {
            //create a temporary file
            Path p = Paths.get("./dat.txt");
            File logFile = p.toFile();
            //write to the temp file 
            writer = new BufferedWriter(new FileWriter(logFile, true));
            writer.write(info + "\n");//test text

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                writer.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /* Log method for calculations saved in math.txt */
    private void mathLog(String in) {
        BufferedWriter writer = null;
        try {
            Path p = Paths.get("./math.txt");
            File mlog = p.toFile();
            writer = new BufferedWriter(new FileWriter(mlog, true));
            writer.write(in + "\n");// <--logs it here
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                writer.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    /* Scrape HTML for info */
    private void quickRun() {

        String line = null;
        int numlns = 0;
        start = System.currentTimeMillis();
        try {
            URL url = new URL(link0);
            url.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
            while ((line = in.readLine()) != null) {
                code[numlns] = line;
                numlns += 1;
            }
            sz0 = numlns;
        } catch (MalformedURLException e) {
            System.out.println("BAD URL");
        } catch (IOException e) {
            e.printStackTrace();
        }
        delt = getElapsedTime();
        System.out.println(numlns + " read in " + delt + " ms\n");
    }

    long getElapsedTime() {
        now = System.currentTimeMillis() - begin;
        return now;
    }

    /* Pull btc prices of major exchanges from the HTML */
    void parse() {
        System.out.println("[" + time + "]");
        /* where things are: 
         * bitstamp line 19 , 200-205
            coinbase 211-220
         * bfx on ~25
         * okCoin on 28 
        Log the extracted Prices */

        double[] market = new double[4];
        market[0] = extract(code[19]);
        market[1] = extract(code[25]);
        market[2] = extract(code[28]);
        market[3] = extract(code[213]);
        log("T=" + getElapsedTime()*0.001 + " ms");
        log(markets[0] + " " + market[0] +" "+ markets[1] +
        " " + market[1] +" "+ markets[2] + " " + market[2] + 
        " "+markets[3] + " " + market[3]);
        log("\n**********");
        member(market);

    }

    /* Pull the doubles (prices) from the strings */
    double extract(String str) {
        
        Double dig = 0.0;
        Matcher m = Pattern.compile("(?!=\\d\\.\\d\\.)([\\d.]+)").matcher(str);
        while (m.find()) {
            double d = Double.parseDouble(m.group(1));
            //System.out.println("\n" + d);
            return d;
        }
        return dig;
    }

    /* Memory */
    void member(double[] newest) {

        double[] del = new double[4];
       
        for (int i = 0; i < 4; i++) {
            String line = "\n";
            if (time > 0) {
                if (newest[i] > history[i][time - 1]) {
                    del[i] = newest[i] - history[i][time - 1];
                    log(markets[i] + " + " + del[i]);
                    plus[i][time] = del[i];
                    line+=Double.toString(del[i]);
                }
                if (newest[i] < history[i][time - 1]) {
                    del[i] = newest[i] - history[i][time - 1];
                    log("**[" + markets[i] + " - " + del[i] + "]**");
                    minus[i][time] = del[i];
                    line+=Double.toString(del[i]);
                }
               
            }

            history[i][time] = newest[i];
        }
    }

    /* 
     * read through memory of price changes to start
     * building a chronology of + and - trading periods 
     * using j as the index of market to calculate
     */
    void calc(int j) {
        /*Method could be called with an int parameter for time 
        which would prescribe bin size to organize add and lost vals
        It would be useful to log this info in a different .txt file */
       
        double[] added = new double[time];
        double[] lost = new double[time];
        double movt=0;
        for (int t = 0; t < time; t++) {
            added[t] += plus[j][t];
            lost[t] += (Math.abs(minus[j][t]));
            movt+=(added[t]-lost[t])/(getElapsedTime()*0.001) ;
              
         
        }
        
       if(movt>0.10){
            mathLog(" ***"+markets[j]+"+$"+movt+" over " + getElapsedTime()*0.001 + " ms ");
       }if(movt<-0.1){
           mathLog(" ***"+markets[j]+"-$"+movt+" over " + getElapsedTime()*0.001 + " ms ");
       }
        /*save the added and lost totals in another [][]
        this could be used to make a bar chart of movt_(time)
        where bar size is based on mag. of movmt[j][t] and color
        is based on + or - sign, and size is based on magnitude as well. 
        The offset would be a reference to history[j][time] which is actual price
        */
        movmt[j][time] = movt;
    }

    /* Simple main method runs whole thing */
    public static void main(String[] args) {

        try {
            new Connect();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
/* Connect.java */
