import java.net.URL;
import java.net.*;
import java.io.*;
import java.util.*;
import java.nio.file.*;

/* Class for file operations */
public class Flies {
    
    static File fil;
    
    public Flies(){
        
    }
    
    /* Create a text file named with parameter*/
    static void makeFile(String name){
        
        String pre = "./";
        String post = ".txt";
        fil = 
        Paths.get(pre+name+post).toFile();
        
    }
    
    /* write text to a file*/
    static void writeFile(String info){
        
        BufferedWriter writer = null;
        try{
            writer = new BufferedWriter(new FileWriter(
                            fil,true));
        writer.write(info);
        }catch(Exception e){e.printStackTrace();}
        finally{
            try{
                writer.close();
            }catch(Exception e){e.printStackTrace();}
        }
    }
    
    /* Returns a file for a given pathname */
    static File getFile(String path){
        String p = "/projects/Coin/src./";
        return  Paths.get(p+path).toFile();
    }
    
    static void readFileIn(File in){
        
    }
    
    public static void main(String []args){
        makeFile("Test");
        writeFile("TESTING TESTING ONE TWO THREE");
        getFile("Test");
        /*
         * read w/ something like:
         * buffered reader(fileinputstream(file(
         *                          str filename )))
         */
        
    }
}
