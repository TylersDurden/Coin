
import java.net.MalformedURLException;
import java.net.URL;
import java.security.cert.Certificate;
import java.io.*;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLPeerUnverifiedException;
import java.util.*;
import java.net.InetAddress;
import java.nio.file.*;

/* Class for accessing https resources and 
viewing server responses to HTTP requests */
public class HttpsClient{
    
    private String[]html = new String[2000];
    static String h=null;       static  String hname=null;
    private static final long start = System.currentTimeMillis();
    
   public static void main(String[] args){
     String in = "https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyDc_H1lZt9oKIQFnp3n7W8hzuPGRubMz5g";
      //String in = "http://ctf06.root-me.org/";
      long start = System.currentTimeMillis();
      new HttpsClient().testIt(in);
      double delt = (System.currentTimeMillis() - start)*0.001;
      
      System.out.println("DONE ["+delt+" ms]");
   }

   private void testIt(String input){
      
      String https_url = input;
      URL url; 
      try {

	     url = new URL(https_url);
	     h = url.toString();
	     int p = url.getDefaultPort();
	     InetAddress [] ip = InetAddress.getAllByName(url.getHost());
	     System.out.println("\n\t**STARTING HTTPS CLIENT WITH HOST: "+h+":"+p+
	     "**\n{ IPS: ");
	     for(int i=0;i<ip.length;i++){System.out.print("\n"+ip[i]);}
	     System.out.print("}\n");
	     HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
       
	     //dumpl all cert info
	     print_https_cert(con);
	     
	     /* Get Headers */
	    auditFields(con);

	     //dump all the content
	     print_content(con);
	     
	     /* Make all then print statements into log(String) 
	      * methods, that instead write info to a file. 
	      */
	     

      } catch (MalformedURLException e) {
	     e.printStackTrace();
      } catch (IOException e) {
	     e.printStackTrace();
      }

   }
    /* Reveal HeaderFields */
    private void auditFields(HttpsURLConnection con){
        
        Map<String, List<String>> headers = con.getHeaderFields();
        Set<Map.Entry<String, List<String>>> entrySet = headers.entrySet();
        
        for (Map.Entry<String, List<String>> entry : entrySet) {
            String headerName = entry.getKey();
            System.out.println("Header Name:" + headerName);
            List<String> headerValues = entry.getValue();
            for (String value : headerValues) {
                System.out.print("Header value:" + value);
            }
            System.out.println();
        }
    }


/* Getting server certificates */
   private void print_https_cert(HttpsURLConnection con){

    if(con!=null){

      try {

	System.out.println("Response Code : " + con.getResponseCode());
	System.out.println("Cipher Suite : " + con.getCipherSuite());
	System.out.println("\n");

	Certificate[] certs = con.getServerCertificates();
	for(Certificate cert : certs){
	   System.out.println("Cert Type : " + cert.getType());
	   System.out.println("Cert Hash Code : " + cert.hashCode());
	   System.out.println("Cert Public Key Algorithm : "
                                    + cert.getPublicKey().getAlgorithm());
	   System.out.println("Cert Public Key Format : "
                                    + cert.getPublicKey().getFormat());
	   System.out.println("\n");
	}

	} catch (SSLPeerUnverifiedException e) { e.printStackTrace();}
	  catch (IOException e){ e.printStackTrace();}

     }

   }

/* Get HTML and save it to String [] */
   private void print_content(HttpsURLConnection con){
	if(con!=null){
	try {
	   System.out.println("\n\t****** Content of the URL ********");
	   BufferedReader br =
		new BufferedReader(
			new InputStreamReader(con.getInputStream()));

	   String input;
        int count=0;
	   while ((input = br.readLine()) != null){
	       System.out.println(input);
	      html[count]=input;
	      count+=1;
	   }
	   System.out.println(count+" lines read and saved");
	   br.close();

	} catch (IOException e) { e.printStackTrace();}

       }
   }
   
   long getElapsedTime() {
        long now = System.currentTimeMillis() - start;
        return now;
    }

/* This method writes parameter String info to a text file 
    called "dat.txt*/
    private void log(String info) {
        BufferedWriter writer = null;
        try {
            //create a temporary file
            Path p = Paths.get("./dat.txt");
            File logFile = p.toFile();
            //write to the temp file 
            writer = new BufferedWriter(new FileWriter(logFile, true));
            writer.write(info + "\n");//test text

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                writer.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
/* HttpsClient.java */