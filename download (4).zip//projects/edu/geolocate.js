/* GEOLOCATION using Google Maps 
Google API Key: Geolocation requests are sent using POST to the following URL:
AIzaSyDc_H1lZt9oKIQFnp3n7W8hzuPGRubMz5g

 *  run this script 
~:$ curl -d @your_filename.json -H "Content-Type: application/json" -i "https://www.googleapis.com/geolocation/v1/geolocate?key=YOUR_API_KEY

 */