/* socks.java */
import java.net.*;
import java.io.*;
import java.nio.*;

/*
 * Just an efficient class for connecting w http 
 */
public class socks {
    
    public socks(){
        System.out.print(connect("http://ctf03.root-me.org"));
    }
    
    static String connect(String link){
        InetAddress [] ips = new InetAddress[10];
        Socket s;
        SocketAddress sa;
        String result = "";
       System.out.print("\t** Connecting **\n");
            try{
            URL url = new URL(link);
            ips = InetAddress.getAllByName(url.getHost());
          
            s = new Socket(ips[0],6667);
            sa = s.getRemoteSocketAddress();
           
            s.close();
        

        }catch(MalformedURLException e){
            e.printStackTrace();
        }catch(UnknownHostException e){
            System.out.print("Unknown Host -"+link);
        } catch(IOException e){
            e.printStackTrace();
        }
       
        
        for(int i=0;i<ips.length;i++){
          result += ips[i]+" ";  
        }
        return result;
    }
    
    public static void main(String[]args){
        new socks();
    }
}
/* socks.java */