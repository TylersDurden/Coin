/* priceHistory.java */
import java.nio.*;
import java.nio.file.*;
import java.io.*;
import java.util.*;

/* Analyze the price history of bitcoin at market close
 * (12AM) for a 1 year range from 8/30/16 - 8/29/2017
 * to use Financial Analysis tools on past price movt 
 * in conjunction with realtime updates and calculations
 * gathered from Connection.java, and logged to math.txt
 * and dat.txt, to make predictions about how the markets 
 * will shift

 * @author scottrobbins
 */
public class priceHistory {

    static File               doc;
    static String[]           lines  = new String[400];
    static String[]           strDays = new String[365];
    static Set<String>        dates  = new HashSet<>();            //dates
    static List<Double>       prices = new ArrayList<>();
    static Map <String,Double> history = new HashMap<String,Double>() ;

    //Useful variable for keeping track of program runtime
    private static final long start  = System.currentTimeMillis();

    public priceHistory() {
        readFile("history.txt");
         
         
        try {
            parseFile();
        } catch (NullPointerException e) {
            System.out.println("/EOF/");
        }
        String date1 = "2017-08-28 00:00:00";
        //System.out.println(dates[0]);
       // System.out.println( getPrice(date1));
       // System.out.println(getDate(578.616575));
       //^Why aren't these working. Would like to avoid arrays and their sidefx 
        
        System.out.println("Finished in " + timeElapsed() + " seconds");
    }

    /* MAIN - just instantiates the priceHistory class */
    public static void main(String[] args) {
        new priceHistory();
    }

    /* This method writes parameter String info to a text file 
     called "dat.txt*/
    private void readFile(String info) {
        BufferedReader br = null;
        FileReader fr = null;

        try {
            fr = new FileReader(info);
            br = new BufferedReader(fr);

            String sCurrentLine;
            String time = null;
            int ln = 0;
            while ((sCurrentLine = br.readLine()) != null) {
                lines[ln] = sCurrentLine;
                time = lines[ln].split(",")[0].split(" 0")[0].trim();
                double price = Double.parseDouble(lines[ln].split(",")[1]);
                System.out.println(time+" : "+price);
                ln+=1;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null)
                    br.close();
                if (fr != null)
                    fr.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

    }

    /* Populate a String set with the date range of prices 
    from the btc history CSV */
    static Map parseFile() throws NullPointerException {
       // Map <String,Double> history = new HashMap<String,Double>();
        int index = 0;
        for (int i = 0; i <= lines.length-1; i++) {
            String[] temp = new String[2];
            temp = lines[i].split(",");
           // prices.add(Double.parseDouble(temp[1]));
           // dates.add(temp[0]);
            history.put(lines[i].split(",")[0],Double.parseDouble(lines[i].split(",")[1]));
        }
        return history;
    }

    /* Show Set <String> of Dates*/
    static void showIT() {
        Iterator<String> it = dates.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }
    }

    /* This method returns elapsed runtime of program*/
    static double timeElapsed() {
        return (System.currentTimeMillis() - start) * 0.001;
    }
    
    /* Get the Date corresping to a specific price in list */
    static String getDate(double price){
        String date = null;
        String result = null;
        int count=0;
        int index = Collections.binarySearch(prices,price);
        Iterator<String> it = dates.iterator();
        boolean found = false;
        while (it.hasNext()==true) {
            date = it.next();
           count++;
           if(count==100){result=date;found=true;}
        }
        return result;
    }
    
    static double getPrice(String date){return history.get(date);}
    // ^^^^^ Returning null. Haven't figured out how to use HashMap correctly... 

}
/* priceHistory.java */
