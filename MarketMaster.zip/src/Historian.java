
import java.util.*;
import java.io.*;
import java.nio.file.*;

/** 
 * Historian gathers all of the historical data
 * available about a market, organizing and 
 * saving it for both later analysis and for 
 * inclusion on a graph 
 * @author Scott
 *
 */
public class Historian implements Runnable {
	
	public Map <Integer,String> hsitory = new HashMap<>();
	public List<Integer>        keyset  = new ArrayList<>();
	public Historian() {
		Analyst.datLog("TESTING 1 2 3 ");
		run();
	}
	
	public void run() {
		
		//get path to csv historic data
		//This is will obviously change 
		Path cb30d = Paths.get("/Users/JoAnna/eclipse-workspace/Analyst/src/btc","./cb30d.csv");
		Path cb7d  = Paths.get("/Users/JoAnna/eclipse-workspace/Analyst/src/btc","./cb7d.csv");
		Path cb24  = Paths.get("/Users/JoAnna/eclipse-workspace/Analyst/src/btc","./cb24hr.csv");
		
		getFileData(cb30d);
		//getFileData(cb7d);
		//getFileData(cb24);
		
	}
	
	private void getFileData(Path p) {
		File f = p.toFile();
		BufferedReader br = null;
		String line = ""; int i =0;
		Map <Integer,String> history = new HashMap<>();
		try {
			br = new BufferedReader(new FileReader(f));
			while((line = br.readLine()) != null ) {
				String [] arr = line.split("UTC");
				for(String s : arr) {
					i++;
					history.put(i, s);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		//Now parse line 
		//System.out.println(history.get(2));// Initial Date and Time 
		//System.out.println(history.get(3)+":"+history.get(4));
		//System.out.println(history.get(5)+":"+history.get(6));
		
		 Map<Integer,Vector<String>> archive = organize(history);
		 for(Integer k:keyset) {
			 System.out.println(archive.get(k));
		 }
	}
	
	private Map<Integer,Vector<String>> organize(Map<Integer,String>datIn) {
		Map <Integer,Vector<String>> out = new HashMap<>();
		
		int index = 0;
		for(Map.Entry<Integer,String>entry:datIn.entrySet()) {
			Vector<String> data = new Vector<>();//<--This!! 
			if(entry.getValue().contains(":")) {
				data.add(entry.getValue());
			}else {
				index += 1;
				keyset.add(index);
				for(String s : entry.getValue().split(",")) {
					s.replaceAll(", ","");
					data.add(s);
					
				}
				System.out.println(data);
			}
			out.put(index, data);
		}
		
		
		return out;
	}
		
	public static void main(String[]args) {
		new Historian();
	}

}
