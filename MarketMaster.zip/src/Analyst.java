/** <ANALYST> */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Analyst implements Runnable {
	
	
	public Analyst(){
	    
	    /************ Process/Workflow of the Analyst *****************
	     * <[1]> Look at Mkt Summary Data and calculate
	     *       - Pivot Price (Base on Current values?)
	     *       - Resistance Level 1 : (R1)
	     *       - Resistance Level 2 : (R2)
	     *       - Support Level 1    : (S1)
	     *       - Support Level 2    : (S2)
	     * <[2]> Make a BST of sorted Trade Data for easy traversal
	     * 
	     * <[3]> Do this for Historic Data as well as Live Data! 
	     *       For Historic data treat each day as it's own entity,
	     *       iterating through all the days included in range. 
 
         * <IDEA>: Put the entire Mkt. Summary methods from DataStream in
         * here for logical/heuristic consistency? Analyst already
         * has the log/timestamp methods. Something to think about! 
 
	     **************************************************************/
		
	}
	
	public void run(){
		
	}
	
	/** Initialize the program*/
	public void init() {
		String logline = "";
		logline += DataStream.TimeStamp();
	}
	
/////** Pull the doubles (prices) from the strings *//
    static double extract(String str) {
        Double dig = 0.0;
        Matcher m = Pattern.compile("(?!=\\d\\.\\d\\.)([\\d.]+)").matcher(str);
        while (m.find()) {
            return Double.parseDouble(m.group(1));
        }
        return dig;
    }
/////////////////////////////////////////////////////
    
    /* Log method for calculations saved in math.txt */
 public static void datLog(String in) {
     BufferedWriter writer = null;
     try {
         Path p = Paths.get("./MktSummary.txt");
         File log = p.toFile();
         writer = new BufferedWriter(new FileWriter(log, true));
         writer.write(in + "\n");// <--logs it here
     } catch (Exception e) {
         e.printStackTrace();
     } finally {
         try {
             writer.close();
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

 }
    
    
}
/** <ANALYST> */