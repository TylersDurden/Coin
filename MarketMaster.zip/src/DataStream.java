/** <DataStream.java> */
import java.util.*;
import java.net.*;
import java.util.regex.*;
import java.io.*;
import java.nio.file.*;
import javax.net.ssl.*;

/** 
 * <DataStream> 
 * collects data about the major bitcoin exchanges and
 * writes it to a text file. 
 * @Author ScottRobbins 
 */
public class DataStream implements Runnable{
    
    //Trades Links uri + resource
    private static String resource = "https://api.cryptowat.ch/markets/";
    private static String BfxOrderbk = "bitfinex/btcusd/trades";
    private static String BstampOrdBk = "bitstamp/btcusd/trades";
    private static String CbaseOrdBk = "coinbase/btcusd/price";
    
    private static String summaryBfnx = "bitfinex/btcusd/summary";
    private static String summaryCb   = "coinbase/btcusd/summary";
    private static String summaryStmp = "bitstamp/btcusd/summary";
    
    private String [] code = new String[1000];
    
    public static Map<Double,Double> bfxDat = new HashMap<>();
    public static Map<Double,Double> bstamp = new HashMap<>();
    public static Map<Double,Double> cbase  = new HashMap<>();
    
    public DataStream() throws InterruptedException {
        run();
      
    }
    
     public void run(){
         Vector<Double>pHist = new Vector<>();
         int i=0;
         int nTries=1;
         boolean run = true;
        while(run == true){
            String ln = "";
            try{
                //Check is the market is slow and we don't need to gather info
                  if(pHist.size()>2){
                    if(pHist.get(pHist.size()-2) - pHist.get(pHist.size()-1)<1.00){
                        datLog(TimeStamp()+" Coinbase: $"+pHist.get(pHist.size()-1));
                        Thread.sleep(5000);
                    }
                }
                // Get Orderbook data 
                new InputData(resource+BfxOrderbk);
                new InputData(resource+BstampOrdBk);
                double p = DataStream.extract(quickPriceCB(resource+CbaseOrdBk).get(0).split(",")[0]);
        
                ln+= " $"+p;
                datLog(ln);
                pHist.add(p);
                
                //////////////////////////////////////////////////////////////////////////////
                //               Get Market Summaries 
                Vector<Double> bfnxSummary  = parseSummary(connect(resource+summaryBfnx));
                Vector<Double> cbaseSummary = parseSummary(connect(resource+summaryCb));
                Vector<Double> stmpSummary  = parseSummary(connect(resource+summaryStmp));
                
                String bfnxSum  = "Bitfinex Market Summary";
                bfnxSum +=" Last:$"+bfnxSummary.get(0)+" High:$"+bfnxSummary.get(1)+
                " Low:$"+bfnxSummary.get(2)+" Volume:"+bfnxSummary.get(3)+"BTC\n";
                String cbSum = "Coinbase Market Summary";
                cbSum += " Last:$"+cbaseSummary.get(0)+" High:$"+cbaseSummary.get(1)+
                " Low:$"+cbaseSummary.get(2)+" Volume:"+cbaseSummary.get(3)+"BTC\n";
                String stmpSum  = "Bitstamp Market Summary";
                stmpSum += " Last:$"+stmpSummary.get(0)+" High:$"+stmpSummary.get(1)+
                " Low:$"+stmpSummary.get(2)+" Volume:"+stmpSummary.get(3)+"BTC\n";
                summaryLog("\t\t\tMARKET SUMMARY\n"+TimeStamp()+
                "\n----------------------------------------------------\n");
                summaryLog(bfnxSum);
                summaryLog(cbSum);
                summaryLog(stmpSum);
                /////////////////////////////////////////////////////////////////////////////
              
                Thread.sleep(15000);
            }catch(InterruptedException e){System.out.print("Something went wrong");}
            i+=1;
            if(i>nTries){run=false;}
        }
        System.exit(0);
    }
    
    
    /** slim main */
    public static void main(String[]args){
        try{new DataStream();
        }catch(InterruptedException e){}
    }
    public class InputData  {
        
        public InputData(String src){
             String datLog = TimeStamp()+"\tsrc= "+src+'\n';
            /** make connection, grab data */
            Vector<String> html = connect(src);
            /** parse data */
            datLog += parse(html);
            datLog(datLog+'\n');
            datLog("\n CB = $");
        
      
        }
    }
    
    
    public static Vector<String> quickPriceCB(String link){
        Vector<String> result = new Vector<>();
        BufferedReader br = null;
        try{
           HttpsURLConnection con  = 
           (HttpsURLConnection) new URL(link).openConnection();
           String line;
           if(con != null){
               br = new BufferedReader(new InputStreamReader(con.getInputStream()));
               while((line = br.readLine()) != null){
                   result.add(line);
               }
           }
        }catch(MalformedURLException e){}
        catch(IOException e){}
        
        return result;
    }
    
   /** Make the connection to the BTC Data */
    public Vector<String> connect(String link) {
        String https = link;
        URL url;
        Vector<String> code = new Vector<>();
        try {
            url = new URL(https);
            HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
            /**Get content*/
           code = getContent(con);
            } 
        catch (MalformedURLException e) { System.out.print("BAD ERL"); }
        catch (IOException e) {e.printStackTrace();}
        return code;
    }
    
    /** Grab content from HTTPS links */
    private Vector<String> getContent(HttpsURLConnection con) {
        Vector<String> code = new Vector<>();
        if (con != null) {
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String line;
                int nLns = 0;
                while ((line = br.readLine()) != null) {
                    //datLog(line);
                    code.add(line);
                    nLns += 1;
                }
                // System.out.print(nLns+" lines read ");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return code;
    }
    
    /** */
   public Vector<Double> parseSummary(Vector<String>code){
       Vector<Double> answer = new Vector<>();
       String [] arr = code.get(0).split(",");
       // summary API : [last,high,low,change,abs,volume,cost,remaining..]
       int index = 0;
       double last = extract(code.get(0).split(",")[0].split("last")[1]);
       double high = 0;
       double low  = 0;
       double vol  = 0;
       for(String e : arr){
           double num = extract(e.split(":")[1]);
           if(index==1){high=num;}
           if(index==2){low=num;}
           if(index==5){vol=num;}
           index+=1;
       }
       answer.add(last);
       answer.add(high);
       answer.add(low);
       answer.add(vol);
       return answer;
   }

    /** parse gathered html */
   public String parse(Vector<String>code){
       String answer = "";
       for(String s: code){
          String [] arr = s.split(","); 
          int x = 0;
          Map<Double,Double> orders = new HashMap<>();
          double [] tees = new double[arr.length];
          for(String e : arr){
              //System.out.print("|"+x+" "+extract(e)+" | ");
              tees[x] = extract(e);
              if(x<arr.length-4){
                 
              }
              x+=1;
              if(x%4==0){ orders.put(tees[x-1],tees[x-2]);}
          }
          
          //Check if orderbook was constructed properly
          int i=0;
          for(Map.Entry<Double,Double>entry : orders.entrySet()){
              System.out.print("Trade "+i+" $"+entry.getValue()+
                               " for "+entry.getKey()+" BTC\n");
              answer += (entry.getValue()+","+entry.getKey()+'\n');
              i++;
          }
          
          
       }
       return answer;
   }
    
    /** Pull the doubles (prices) from the strings */
    static double extract(String str) {
        Double dig = 0.0;
        Matcher m = Pattern.compile("(?!=\\d\\.\\d\\.)([\\d.]+)").matcher(str);
        while (m.find()) {
            return Double.parseDouble(m.group(1));
        }
        return dig;
    }
    
       /* Log method for calculations saved in math.txt */
    public static void datLog(String in) {
        BufferedWriter writer = null;
        try {
            Path p = Paths.get("./Log.txt");
            File log = p.toFile();
            writer = new BufferedWriter(new FileWriter(log, true));
            writer.write(in + "\n");// <--logs it here
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                writer.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
    
    public static void summaryLog(String in){
        BufferedWriter bw = null;
        try{
            Path p = Paths.get("./MktSummary.txt");
            File log = p.toFile();
            bw = new BufferedWriter(new FileWriter(log,true));
            bw.write(in+"\n");
        }catch(Exception e){e.printStackTrace();}
        finally{
            try{
                bw.close();
            }catch(Exception e){e.printStackTrace();}
        }

    }
    
    
    /** Method to generate a Time Stamp */
    public static String TimeStamp() {
        //set todays date, and initialize a calendar for calculations
        TimeZone est = TimeZone.getTimeZone("EST");
        Calendar c = Calendar.getInstance(est, Locale.US);

        String cs = c.toString();
        String mo = Integer.toString(Integer.parseInt(cs.split(",MONTH=")[1].split(",")[0]) + 1);//Indexed from 0!!
        String yr = cs.split(",YEAR=")[1].split(",")[0];
        String day = cs.split("DAY_OF_MONTH=")[1].split(",")[0];
        String hr = Integer.toString(Integer.parseInt(cs.split("HOUR=")[1].split(",")[0]));//toInt
        String min = cs.split("MINUTE=")[1].split(",")[0];
        String sec = cs.split("SECOND=")[1].split(",")[0];
        String mer = "";//(meridian) so AM or PM
        if (cs.split("AM_PM=")[1].split(",")[0].compareTo("1") == 0) {
            mer += "PM";
        } else {
            mer += "AM";
        }
        //hm so any of the three could be less than 10 but each might be different
        String dateHead = mo + "/" + day + "/" + yr + " " + hr + ":" + min + ":" + sec + " " + mer;
   
        return dateHead;
    }
    
    


}
/** <DataStream.java> */
