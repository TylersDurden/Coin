#!/usr/lib/python3

import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

f = open('${current.project.path}','r')

# Sort Trades by Volume 
"""
Orders = {$price - $mkt:[price,volume]...}
"""

