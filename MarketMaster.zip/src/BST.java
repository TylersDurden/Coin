/**
 * Modified version of code found in
 * an Introduction to Programming in Java
 * by Robert Sedgewick and Kevin Wayne 
 */
public class BST <Key extends Comparable<Key>, Value> {
    
    private Node root;
    
    private class Node{
        Key key;
        Value val;
        Node left, right;
        Node(Key key, Value val){this.key = key; this.val = val; }
        
    }
    
    /** Traversing with recursion **/
    public Value get(Key key){return get(root,key);}
    
    private Value get(Node x, Key key){
        Value nl;
        int comp = key.compareTo(x.key);
        if(comp<0)      return get(x.left, key);
        else if(comp>0) return get(x.right,key);
        else            return x.val;
        
    }
    
    public boolean contains(Key key){return (get(key) != null);}
    
    public void put(Key key, Value val){root = put(root,key,val);}
    
    private Node put(Node x, Key key , Value val){
        if(x==null) return new Node(key,val);
        int compare = key.compareTo(x.key);
        if(compare<0)       x.left = put(x.left,key,val);
        else if(compare>0)  x.right = put(x.right, key,val);
        else                x.val = val;
        return x;
    }
    
    
}
